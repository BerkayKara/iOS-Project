//
//  Compare+CoreDataClass.swift
//  BK Cars
//
//  Created by CTIS Student on 3.06.2020.
//  Copyright © 2020 CTIS. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Compare)
public class Compare: NSManagedObject {
    class func createInManagedObjectContext(_ context: NSManagedObjectContext, brand: String, model: String, year: String, category: String, power: String,torque: String, price: String) -> Compare {
               let compareObject = NSEntityDescription.insertNewObject(forEntityName: "Compare", into: context) as! Compare
               compareObject.brand = brand
               compareObject.model = model
               compareObject.year = year
               compareObject.category = category
               compareObject.power = power
               compareObject.torque = torque
               compareObject.price = price

               return compareObject
           
       }

}
