//
//  Compare+CoreDataProperties.swift
//  BK Cars
//
//  Created by CTIS Student on 3.06.2020.
//  Copyright © 2020 CTIS. All rights reserved.
//
//

import Foundation
import CoreData


extension Compare {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Compare> {
        return NSFetchRequest<Compare>(entityName: "Compare")
    }

    @NSManaged public var brand: String?
    @NSManaged public var model: String?
    @NSManaged public var power: String?
    @NSManaged public var year: String?
    @NSManaged public var torque: String?
    @NSManaged public var price: String?
    @NSManaged public var category: String?

}
