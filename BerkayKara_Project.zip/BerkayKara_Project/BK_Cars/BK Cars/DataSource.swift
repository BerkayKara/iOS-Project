//
//  DataSource.swift
//  CTIS480_Spring1920_HW2
//
//  Created by Syed Ali on 4/22/20.
//  Copyright © 2020 CTIS. All rights reserved.
//

import Foundation

class DataSource {
    var mRecordList: [Car] = []
    var categories: [String] = []
    
    func numbeOfItemsInEachCategory(index: Int) -> Int {
        return itemsInCategory(index: index).count
    }
    
    func numberOfCategories() -> Int {
        return categories.count
    }
    
    func getCategoryLabelAtIndex(index: Int) -> String {
        return categories[index]
    }
    
    // MARK:- Populate Data from files
    
    func populate(type: String) {

               if let path = Bundle.main.path(forResource: "car", ofType: "xml") {
                   if let xmlToParse = NSData(contentsOfFile: path) {
                       
                       let xml = SWXMLHash.parse(xmlToParse as Data)
                       
                       
                       for data in xml["main"]["item"].all{
                           let brand = data["brand"].element!.text
                           let model = data["model"].element!.text
                           let year = data["year"].element!.text
                           let price = data["price"].element!.text
                           let power = data["power"].element!.text
                           let torque = data["torque"].element!.text
                           let category = data["category"].element!.text
                           let img = data["img"].element!.text
                       
                           let record = Car(brand: brand, model: model, year: year, price: price, power: power, torque: torque, category: category, img: img)

                           if !categories.contains(category) {
                               categories.append(category)
                           }
                           
                           mRecordList.append(record)
                       
                       }
                       
                   }
                   else {
                       print("NSData error")
                   }
               }
               else {
                   print("Path error")
               }
           }
       
    
    
    // MARK:- itemsForEachGroup
    func itemsInCategory(index: Int) -> [Car] {
        let item = categories[index]
        
        // See playground6 for Closure
        // http://locomoviles.com/uncategorized/filtering-swift-array-dictionaries-object-property/
        
        let filteredItems = mRecordList.filter { (record: Car) -> Bool in
            return record.category == item
        }
        
        return filteredItems
    }
    
}
