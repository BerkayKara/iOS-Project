//
//  CustomTableViewCell.swift
//  BK Cars
//
//  Created by CTIS Student on 9.06.2020.
//  Copyright © 2020 CTIS. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

   
    @IBOutlet weak var mImage: UIImageView!
    
    @IBOutlet weak var brand: UILabel!
    
    @IBOutlet weak var model: UILabel!
}
