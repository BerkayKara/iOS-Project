//
//  Graph.swift
//  BK Cars
//
//  Created by CTIS Student on 6.06.2020.
//  Copyright © 2020 CTIS. All rights reserved.
//

import UIKit
import Charts
import CoreData

class GraphVC: UIViewController, ChartViewDelegate {
    
    var barchart = BarChartView()
    var mCompare = [Compare]()
    var entries = [BarChartDataEntry]()

    @IBOutlet weak var segment: UISegmentedControl!
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        barchart.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.width)
        
        barchart.center = view.center
        
        view.addSubview(barchart)
        
        let set = BarChartDataSet(entries: entries)
        set.colors = ChartColorTemplates.joyful()
        
        let data = BarChartData(dataSet: set)
        
        barchart.data = data
        
    }
    
    func fillBarEntriesPower(){
        let count = mCompare.count
        for x in 0..<count{
            entries.append(BarChartDataEntry(x: Double(x), y: Double(mCompare[x].power ?? "0.0")!))
                
            
        }
    }
    
    func fillBarEntriesTorque(){
        let count = mCompare.count
        for x in 0..<count{
            entries.append(BarChartDataEntry(x: Double(x), y: Double(mCompare[x].torque ?? "0.0")!))
                
            
        }
    }
    
    func fillBarEntriesYear(){
        let count = mCompare.count
        for x in 0..<count{
            entries.append(BarChartDataEntry(x: Double(x), y: Double(mCompare[x].year ?? "0.0")!))
                
            
        }
    }
    
    
    func fillBarEntriesPrice(){
        let count = mCompare.count
        for x in 0..<count{
            entries.append(BarChartDataEntry(x: Double(x), y: Double(mCompare[x].price ?? "0.0")!))
                
            
        }
    }
    
    @IBAction func onSegmentChanged(_ sender: UISegmentedControl) {
        
       switch sender.selectedSegmentIndex {
        case 0:
            label.text = "Currently Comparing:  Power (hp)"
            entries.removeAll()
            self.fillBarEntriesPower()
        case 1:
            label.text = "Currently Comparing:  Torque (Nm)"
            entries.removeAll()
            self.fillBarEntriesTorque()
        case 2:
            label.text = "Currently Comparing:  Year"
            entries.removeAll()
            self.fillBarEntriesYear()
        case 3:
            label.text = "Currently Comparing:  Price (€)"
            entries.removeAll()
            self.fillBarEntriesPrice()
        default:
            label.text = "Currently Comparing:  Power (hp)"
            entries.removeAll()
            self.fillBarEntriesPower()
            }

    }
    
    // Our function to fetch data from Core Data
    func fetchData() {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Compare")
        
        
        do {
            let results = try context.fetch(fetchRequest)
            mCompare = results as! [Compare]
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.fetchData()
        self.fillBarEntriesPower()//by default
        barchart.delegate = self
    }
}
