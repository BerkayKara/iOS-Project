//
//  ViewController.swift
//  BK Cars
//
//  Created by CTIS Student on 23.05.2020.
//  Copyright © 2020 CTIS. All rights reserved.
//

import UIKit

class MainVC: UIViewController {

    @IBOutlet weak var modeLabel: UILabel!
    
    
    @IBOutlet weak var titleCar: UILabel!
    @IBOutlet weak var seeAll: UIButton!
    
    @IBOutlet weak var compareCars: UIButton!
    
    @IBOutlet weak var mImage: UIImageView!
    
    var flag = 0
    
    
    @objc func onTap() {
        
        if flag == 0 {
            view.backgroundColor = UIColor.white
            titleCar.textColor = UIColor.black
            modeLabel.textColor = UIColor.black
            seeAll.titleLabel?.textColor = UIColor.black
            compareCars.titleLabel?.textColor = UIColor.black
            modeLabel.text = "Click here to enable Dark Mode"
            mImage.image = UIImage(named: "bmwWhite")
            flag = 1
        }
        else if flag == 1 {
            view.backgroundColor = UIColor.black
            titleCar.textColor = UIColor.white
            modeLabel.textColor = UIColor.white
            seeAll.titleLabel?.textColor = UIColor.white
            compareCars.titleLabel?.textColor = UIColor.white
            modeLabel.text = "Click here to enable White Mode"
            mImage.image = UIImage(named: "mainBMW")
            flag = 0
        }
        
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.onTap)) // GESTURE RECOGNIZER ???
        modeLabel.addGestureRecognizer(tapGesture)
        
        
    }
    
    @IBAction func unwindToMain(_ sender: UIStoryboardSegue) {
        if flag == 1 {
            view.backgroundColor = UIColor.white
            titleCar.textColor = UIColor.black
            modeLabel.textColor = UIColor.black
            seeAll.titleLabel?.textColor = UIColor.black
            compareCars.titleLabel?.textColor = UIColor.black
            modeLabel.text = "Click here to enable Dark Mode"
            mImage.image = UIImage(named: "bmwWhite")
            flag = 1
        }
        else if flag == 0 {
            view.backgroundColor = UIColor.black
            titleCar.textColor = UIColor.white
            modeLabel.textColor = UIColor.white
            seeAll.titleLabel?.textColor = UIColor.white
            compareCars.titleLabel?.textColor = UIColor.white
            modeLabel.text = "Click here to enable White Mode"
            mImage.image = UIImage(named: "mainBMW")
            flag = 0
        }
    }

}

