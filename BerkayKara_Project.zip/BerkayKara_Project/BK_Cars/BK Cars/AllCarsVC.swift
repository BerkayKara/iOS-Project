//
//  AllCarsVC.swift
//  BK Cars
//
//  Created by CTIS Student on 23.05.2020.
//  Copyright © 2020 CTIS. All rights reserved.
//

import UIKit

class AllCarsVC: UIViewController {
    
    @IBOutlet weak var mTableView: UITableView!
    
    
    let dataJSON = DataSource()

    func getIndex() -> IndexPath? {
        var index: IndexPath?
        if mTableView.indexPathsForSelectedRows!.count > 0 {
            index = mTableView.indexPathsForSelectedRows![0] as IndexPath
        }
        return index
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "detail"{
            if let index = getIndex(){
                let record = dataJSON.itemsInCategory(index: index.section)[index.row]
                let detailVC = segue.destination as! DetailVC
                
                detailVC.record = record
            
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        dataJSON.populate(type: "xml")
    }
}

extension AllCarsVC: UITableViewDataSource, UITableViewDelegate{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return dataJSON.numberOfCategories()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataJSON.numbeOfItemsInEachCategory(index: section)
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //var cell = UITableViewCell()
        
        // Recommended way
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomTableViewCell
        
        let records: [Car] = dataJSON.itemsInCategory(index: indexPath.section)
        let record = records[indexPath.row]
        
        cell.brand?.text = record.brand.capitalized
        cell.model?.text = record.model
        cell.mImage?.image = UIImage(named: record.img.lowercased())
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0
    }
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40.0
    }
    
    // Setting the header title for each section
    /*func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
     
     return mDataSource.getSectionLabelAtIndex(section)
     }*/
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let label : UILabel = UILabel()
        label.textAlignment = NSTextAlignment.center
        label.backgroundColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        label.text = dataJSON.getCategoryLabelAtIndex(index: section)
        label.font = UIFont(name: "HelveticaNeue-Bold", size: 20.0)
        label.textColor = UIColor(red: 1.0, green:1.0, blue: 1.0, alpha: 1.0)
        return label
    }
    
    
}
