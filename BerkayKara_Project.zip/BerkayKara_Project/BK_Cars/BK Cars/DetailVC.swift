//
//  DetailVC.swift
//  BK Cars
//
//  Created by CTIS Student on 23.05.2020.
//  Copyright © 2020 CTIS. All rights reserved.
//

import UIKit
import CoreData
import AVFoundation


class DetailVC: UIViewController {

    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var brandLabel: UILabel!
    @IBOutlet weak var modelLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var powerLabel: UILabel!
    @IBOutlet weak var torqueLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    
    
    
    var mCompare = [Compare]()
    var audioPlayer: AVAudioPlayer!

    
    var record = Car(brand: "", model: "", year: "", price: "", power: "", torque: "", category: "", img: "")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        image.image = UIImage(named: "\(record.img)")
        brandLabel.text = "Brand: " + record.brand
        modelLabel.text = "Model: " + record.model
        yearLabel.text = "Year: " + record.year
        powerLabel.text = "Power(hp): " + record.power
        torqueLabel.text = "Torque(Nm): " + record.torque
        priceLabel.text = "Price(€): " + record.price
        navigationItem.title = record.category
        


    }
    
    @IBAction func onAdd(_ sender: UIButton) {
        self.saveNewItem(record.brand, model: record.model ,year: record.year ,category: record.category, power: record.power , torque: record.torque,  price: record.price)
        let car = "\(record.brand)" + "\(record.model)"
        let empty = UIAlertController(title: "Car Added to Compare List", message: "\(car)" + " is now in your compare list.", preferredStyle: .alert)
        // Event Handler for the button
        empty.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
        // Displaying the Alert
        self.present(empty, animated: true, completion: nil)
        playSound()
        
    }
    
    
    func save() {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        do {
            try context.save()
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
    }
    
    
    func fetchData() {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Compare")
        
        
        do {
            let results = try context.fetch(fetchRequest)
            mCompare = results as! [Compare]
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
        
    }
    
    // Method to insert data into Table View and save in Core Data
    func saveNewItem(_ brand: String, model: String, year: String, category: String, power: String,torque: String, price: String) {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        

        
        // Create the new Student item
        let newStudentItem = Compare.createInManagedObjectContext(context, brand: brand, model: model, year: year, category: category, power: power,torque: torque, price: price)
        
       // Update the array containing the table view row data
        self.fetchData()
        
        // Use Swift's FirstIndex function for Arrays to figure out the index of the newStudentItem
        // after it's been added and sorted in our mStudent array
        if let newStudentIndex = mCompare.firstIndex(of: newStudentItem) {
            // Create an NSIndexPath from the newStudentIndex
            _ = IndexPath(row: newStudentIndex, section: 0)
            // Animate in the insertion of this row
            save()
        }
       
    }
    
    func playSound() {
        let soundURL = Bundle.main.url(forResource: "car", withExtension: "wav")
        audioPlayer = try! AVAudioPlayer(contentsOf: soundURL!)
        audioPlayer.play()
        print("sound ok")
    }
}
