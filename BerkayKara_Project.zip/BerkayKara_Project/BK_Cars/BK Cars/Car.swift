//
//  Record.swift
//  CTIS480_Spring1920_HW2
//
//  Created by Syed Ali on 4/22/20.
//  Copyright © 2020 CTIS. All rights reserved.
//

import Foundation

class Car {
    var brand: String
    var model: String
    var year: String
    var price: String
    var power: String
    var torque: String
    var category: String
    var img: String
    
    init(brand: String, model: String, year: String, price: String, power: String, torque: String, category: String, img: String) {
        self.brand = brand
        self.model = model
        self.year = year
        self.price = price
        self.power = power
        self.torque = torque
        self.category = category
        self.img = img
    }
        
}
