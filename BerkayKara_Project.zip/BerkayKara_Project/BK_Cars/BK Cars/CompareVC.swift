//
//  CompareVC.swift
//  BK Cars
//
//  Created by CTIS Student on 25.05.2020.
//  Copyright © 2020 CTIS. All rights reserved.
//

import UIKit
import CoreData


class CompareVC: UIViewController {

    
    var mCompare = [Compare]()

    
    
    @IBOutlet weak var mTableView: UITableView!
    
    
    func save() {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        do {
            try context.save()
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
    }
    
    // Our function to fetch data from Core Data
    func fetchData() {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Compare")
        
        
        do {
            let results = try context.fetch(fetchRequest)
            mCompare = results as! [Compare]
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.fetchData()

        // Do any additional setup after loading the view.
    }
    

    
}
extension CompareVC: UITableViewDataSource,UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mCompare.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Recommended way
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
        
        // Get the Student for this index
        let compare = mCompare[indexPath.row]
        
        cell.textLabel?.text = compare.brand! + " " + compare.model!
        cell.detailTextLabel?.text = "Power = " + compare.power! + ", Torque = " + compare.torque!
        
        return cell
    }
    
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        if(editingStyle == .delete ) {
            // Find the Student object the user is trying to delete
            let studentToDelete = mCompare[indexPath.row]
            
            // Delete it from the managedObjectContext
            context.delete(studentToDelete)
            
            // Delete it from mStudent Array
            mCompare.remove(at: indexPath.row)
            
            // Tell the table view to animate out that row
            mTableView.deleteRows(at: [indexPath], with: .automatic)
            
            save()
        }
    }
    
    func getIndexPathForSelectedRow() -> IndexPath? {
        var indexPath: IndexPath?
        
        if mTableView.indexPathForSelectedRow!.count > 0 {
            indexPath = mTableView.indexPathsForSelectedRows![0] as IndexPath
        }
        return indexPath
    }
    
}
